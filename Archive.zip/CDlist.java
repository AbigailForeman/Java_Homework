class CDList<E> implements Cloneable{
  //--------------nested node class------------
  private static class Node<E> {
    private E element;
    private Node<E> prev;
    private Node<E> next;
    public Node(E e, Node<E> p, Node<E> n) {
      element = e;
      prev = p;
      next = n;
    }
    public E getElement() { return element; }
    public Node<E> getPrev() { return prev; }
    public Node<E> getNext() { return next; }
    public void setPrev(Node<E> p) { prev = p; }
    public void setNext(Node<E> n) { next = n; }
    public String toString() {
      return "(" + prev.getElement() +"," + element + "," +
              next.getElement() +")";
    }
  }
  //---------------end of nested node class------------
//Member data
  private Node<E> tail = null;
  private int size = 0;
  //Member Methods
  public CDList() {
  //default constructor

  }
  public CDList(CDList<E> cdl) {
  //the copy constructor
   CDList<E> cdList= new CDList<E>();
   this.tail = cdl.tail;
   this.size = cdl.size;
    if (size > 0) {
      cdList.tail = new Node<>(this.tail.getElement(), tail.getPrev(), tail.getNext());
      Node<E> walk = tail.getNext();
      while (walk != tail) {
        cdList.addLast(walk.getElement());
        walk = walk.getNext();
      }
      cdList.addLast(walk.getElement());
    }

  }
  public int size() {
    return size;//returns the size of the list
  }
  public boolean isEmpty() {
    return (size == 0);//checks if the list is empty
  }
  public E first() {
    if(isEmpty()) return null;
    return tail.getNext().getElement();//return the first element of the list
  }
  public E last() {
    if(isEmpty()) return null;
    return tail.getElement();//return the last element of the list
  }
  public void rotate() {
  //rotate the first element to the back of the list
    if (tail != null) // if empty, do nothing
    tail = tail.getNext();
  }
  public void rotateBackward() {
  //rotate the last element to the front of the list
    if (tail != null) // if empty, do nothing
      tail = tail.getPrev();
  }
  public void addFirst(E e) {
  //add element e to the front of the list
    if (size == 0) {
      tail = new Node<>(e, null, null);
      tail.setNext(tail); // link to itself circularly
      tail.setPrev(tail);
    } else {
      Node<E> newest = new Node<>(e, tail, tail.getNext());
      tail.setNext(newest);
      tail.getNext().getNext().setPrev(newest);
    }
    size++;
  }
  public void addLast(E e) {
    //add element e to the back of the list
    if (size == 0) {
      tail = new Node<>(e, null, null);
      tail.setNext(tail); // link to itself circularly
      tail.setPrev(tail);
    } else {
      Node<E> newest = new Node<>(e, tail, tail.getNext());
      tail.setNext(newest);
      tail.getNext().getNext().setPrev(newest);
      tail = newest;
    }
    size++;
  }
  public E removeFirst() {
//remove and return the element at the front of the list
    if (isEmpty( )) return null;
    E head = tail.getNext( ).getElement();
    if (tail.getNext() == tail) tail = null;
    else {
      tail.setNext(tail.getNext().getNext());
      tail.getNext().setPrev(tail);
    }
    size--;
    return head;
  }
  public E removeLast() {
//remove and return the element at the back of the list
    if (isEmpty( )) return null;
    E end = tail.getElement();
    if (tail.getNext() == tail) tail = null;
    else {
      tail.getPrev().setNext(tail.getNext()); //go to the prev and jump over
      tail.getNext().setPrev(tail.getPrev());
    }
    size--;
    return end;
  }
  public CDList<E> clone(){
//clone and return the new list(deep clone)
  CDList<E> copy = new CDList<E>();
    if (size > 0){
      copy.tail = new Node<>(this.tail.getElement(), tail.getPrev(), tail.getNext());
      Node<E> walk = tail.getNext();
      while (walk != tail) {
        copy.addLast(walk.getElement());
        walk = walk.getNext();
      }
      copy.addLast(walk.getElement());
    }
    return copy;
  }

  public boolean equals(Object o) {
//check if the current instance and o are from the same class, have
//    the same type
//and have the same sequence of elements despite
//having possibly different starting points.
    if (o == null) return false;
    if (getClass( ) != o.getClass( )) return false;
    CDList other = (CDList) o; // use nonparameterized type
    if (size != other.size) return false;
    Node walkA = tail; // traverse the primary list
    Node walkB = other.tail; // traverse the secondary list
      while (walkA != tail) {
        if (!walkA.getElement().equals(walkB.getElement())) return false; //mismatch
        walkA = walkA.getNext();
        walkB = walkB.getNext();
      }

       return true; // if we reach this, everything matched successfully
  }

  public void attach(CDList cdl) {
//insert cdl after the tail of the current list$
    if (cdl.size > 0) {

      Node<E> walk = cdl.tail.getNext();
      while (walk != cdl.tail) {
        this.addLast(walk.getElement());
        walk = walk.getNext();
      }
      this.addLast(walk.getElement());
    }
  }
  public void removeDuplicates() {
  //remove all elements that happen more than once in the list. If the
  //   tail gets //deleted, the element immediately before the tailÂ will become
  //   the new tail.

    Node walk = tail.getNext();
    do{
     Node comp = walk.getNext();
      while(comp != walk){
        if(comp.getElement() == walk.getElement()) {
          if(tail == comp) tail = comp.getPrev();
          comp.getPrev().setNext(comp.getNext()); //go to the prev and jump over
          comp.getNext().setPrev(comp.getPrev());
          size--;
        }
        comp = comp.getNext();
      }
      walk = walk.getNext();
    } while (walk != tail.getNext());

    }



    public void printList() {
//prints all elements in the list
    if (size == 0)
      System.out.println("List is empty.");
    else {
      Node<E> walk = tail.getNext();
      while (!(walk.getNext().equals(tail.getNext()))) {
        System.out.print(walk.toString() + ", ");
        walk = walk.getNext();
      }
      System.out.println(walk.toString());
    }
  }
}